package demo;

import com.alibaba.fastjson.JSONObject;
import com.szfy.did.DidServiceSDK;
import com.szfy.did.sdk.config.DidSystemConfig;

/**
 * 文件服务测试,用于测试文件上传接口
 *
 * @author luopb
 */
public class FileTest {
    //使用方公钥
    private static String publicKey = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAiBUbkWeIcnNRtUvdyDO/1241gHNMQSHetkuqTGuFJltpix7oZ+Q+8hi+azQ9URyxmHghMORvcwk0ck2qOYYD9t75cpt//rY9h9PX7fxJqYCBP5zVhfeSBbcex/n84c6uxgRsHxKaZ2A5LOM9vHaNotw6/V2bVRH/a/Fv4OC5SP3MizIVpejm3I81gZS9VHEUWsv4R0QjjsO7c+QIEUOpBDDtlokvc+dkVuahUZ2cHZGKtT+kT1VD3Yd9enY/xNwj7Ef3ItCb/YmCA/ngj4uONC+N0X7Femt7wxTjGwpKmSn+CPBR0t1lFExLKebihEuezpjGSpKTMO+V2HPX6BIu6wIDAQAB";
    //调用方系统ID
    private static String systemId = "eBank";
    //文件上传返回数据
    private static String uploadFileInfo = "";


    public static void main(String[] args) throws Exception {
        //准备创建实例参数，用以下方接口调用
        String systemId = "eBank";   //调用方系统ID
        String publicKey = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAiBUbkWeIcnNRtUvdyDO/1241gHNMQSHetkuqTGuFJltpix7oZ+Q+8hi+azQ9URyxmHghMORvcwk0ck2qOYYD9t75cpt//rY9h9PX7fxJqYCBP5zVhfeSBbcex/n84c6uxgRsHxKaZ2A5LOM9vHaNotw6/V2bVRH/a/Fv4OC5SP3MizIVpejm3I81gZS9VHEUWsv4R0QjjsO7c+QIEUOpBDDtlokvc+dkVuahUZ2cHZGKtT+kT1VD3Yd9enY/xNwj7Ef3ItCb/YmCA/ngj4uONC+N0X7Femt7wxTjGwpKmSn+CPBR0t1lFExLKebihEuezpjGSpKTMO+V2HPX6BIu6wIDAQAB";
        //单实例，创建一个对象，用于服务调用
        DidSystemConfig.getInstance().setSystemId(systemId);
        DidSystemConfig.getInstance().setPublicKey(publicKey);

        //文件上传
        uploadFile();
        //文件下载
        downFile();
    }


    //1、文件上传接口
    public static void uploadFile() throws Exception {
        //本地准备上传文件地址
        String localPath = "C:\\Users\\86183\\Desktop\\qkll.png";
        //上传文件名
        String fileName = "sfz002.png";
        //保存到服务的相对路径
        String remotePath = "/2022/06/baseinfo";
        //请求流水号
        String seqNo = DidServiceSDK.getSeqNo(systemId);
        //上传文件

        String retStr = DidServiceSDK.uploadFile(localPath, fileName, remotePath, seqNo);
        System.out.println("文件上传信息 ===> "+retStr);

        //将retStr保存为全局变量，在后续文件下载示例中使用
        uploadFileInfo = retStr;
    }

    //2、文件下载
    public static void downFile() throws Exception {
        //请求流水号
        String seqNo = DidServiceSDK.getSeqNo(systemId);
        //文件信息（这里使用文件上传时保存的数据）
        JSONObject retStrJson = JSONObject.parseObject(uploadFileInfo);
        String fileId = retStrJson.getJSONObject("body").getString("fileId"); //文件ID
        String aesRandomKey=retStrJson.getJSONObject("body").getString("aesRandomKey");//文件密钥
        //文件保存到的本地路径
        String localPath = "C:\\Users\\86183\\Desktop\\testFile";
        //提供2种下载方式
        //解密后的图片下载
        DidServiceSDK.downloadFileAndDecrypt(fileId, localPath, aesRandomKey, seqNo);
        //未解密的图片下载
        //didFileSDK1.downloadFile(fileId, localPath, seqNo);
    }
}
