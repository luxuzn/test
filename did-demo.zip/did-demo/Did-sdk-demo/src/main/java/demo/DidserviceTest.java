package demo;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.szfy.did.DidSecurityTools;
import com.szfy.did.DidServiceSDK;
import com.szfy.did.sdk.config.DidSystemConfig;
import com.szfy.did.sdk.config.ServiceUrlConstant;

import java.util.HashMap;
import java.util.Map;

public class DidserviceTest {
    private static Map<String, byte[]> checkMap = new HashMap<>();

    public static void main(String[] args) throws Exception {
        /**
         * 初始化系统参数(必须提前初始化)
         */
        String systemId = "eBank";   //调用方系统ID
        String publicKey = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAiBUbkWeIcnNRtUvdyDO/1241gHNMQSHetkuqTGuFJltpix7oZ+Q+8hi+azQ9URyxmHghMORvcwk0ck2qOYYD9t75cpt//rY9h9PX7fxJqYCBP5zVhfeSBbcex/n84c6uxgRsHxKaZ2A5LOM9vHaNotw6/V2bVRH/a/Fv4OC5SP3MizIVpejm3I81gZS9VHEUWsv4R0QjjsO7c+QIEUOpBDDtlokvc+dkVuahUZ2cHZGKtT+kT1VD3Yd9enY/xNwj7Ef3ItCb/YmCA/ngj4uONC+N0X7Femt7wxTjGwpKmSn+CPBR0t1lFExLKebihEuezpjGSpKTMO+V2HPX6BIu6wIDAQAB";
        //单实例，创建一个对象，用于服务调用
        DidSystemConfig.getInstance().setSystemId(systemId);
        DidSystemConfig.getInstance().setPublicKey(publicKey);

         //调用接口示例
        //2.1用户申请DID
        //userRegisterInfo();
        //2.2数据上链
        //coChainData();
        //2.3数据查看权限申请
        //permissionToView();
        //2.4待授权信息查询
        //applicationEnquiry();
        //2.5用户授权
        //authorization();
        //2.6权限申请结果查询
         UserApplicationEnquiry();
        //2.7查询链上加密数据
         getChainList();
        //2.8通过did 获取公钥
        //getPublicKey();
        //2.9获取用户基本信息
        //userFind();
        //2.10链上数据校验
         //checkData();

    }


    //2.1用户申请DID
    public static void userRegisterInfo() throws Exception {
        //请求报文
        String reqData = "{\n" +
                "\t\"syshead\": {\n" +
                "\t\t\"consumerSysid\": \"123456\",\n" +
                "\t\t\"date\": \"20220512\",\n" +
                "\t\t\"time\": \"1526\",\n" +
                "\t\t\"tellerNo\": \"65414445451212\",\n" +
                "\t\t\"organNo\": \"501161000019\"\n" +
                "\t},\n" +
                "\t\"body\": {\n" +
                "\t\t\"userName\": \"xiaowei\",\n" +
                "\t\t\"publicKey\": \"-----BEGIN PUBLIC KEY-----\\nMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAlxliJnUhuKS92ptr/AMO\\nakf1bHJmB5sfCx/iI3GcQSqL8iUFHZKMbuqe5SAfy/XOYNVHDsJdcZm44i63ABzC\\nHjATMf7zzEMYbpDu9rjfhTu65E0C6tpNPQNt7XqyTOcrwwq1FGgCWyzRb3EIDuzy\\n5cFyaHIWMHJvu+xETUl1ns+gqH5HFGgoNXw52RrTlZey0PhiUuTUeoz0wprthCjW\\nblHP3lhsytMBuR2Qzap7zAQTt+VkJ/vE8arI9n43239qR1cSEatDEIc28oO1W+2B\\nIocG3e1RkT0WEkCECjMq+lQfake59v9P/G2Pmr7wUw8XDsolSWlB9ZqRGNMHEedX\\nzQIDAQAB\\n-----END PUBLIC KEY-----\",\n" +
                "\t\t\"signature\": \"JrJ71nxN/l8zwq72rkk5S1boJ1ys1/MF3AXeovsWjlD4WQwVXCcGtV05fxQvkabIKnHj8W71iJnmANiKSdzuypJYsDWPzKkd2nKsegFboM949LrrDyftqo14GEPH75MdRfMy6MA5RgvssSlsDV2e8X6u4ms1RqvEH5kiLPVmbCQCuUnpShe4TJHOO82ysV/BHCgvZOwrU4eFXEleb1a63VoSS8GqS8xEiCrzrlxJ6PNC8E3MRlNZ4Gtprzu+LcYWRHbRdyX+eEnin7dKaCVf2aJzIJVjynrbXtWe6WowmxysA50TkVLvnnSaHh+0IqsodoaieX1XCuYGmBaLS3fA1w==\"\n" +
                "\t}\n" +
                "}";
        //请求流水号
        String seqNo = DidServiceSDK.getSeqNo(DidSystemConfig.getInstance().getSystemId());
        //当前接口对应的URL
        String serviceUrl = ServiceUrlConstant.USER_DID_REGISTER_URL;
        //发送并返回响应报文
        String responsData = DidServiceSDK.sendToSaaS(reqData, seqNo, serviceUrl);
        System.out.println("响应报文 =====>" + responsData);
    }


    //2.2数据上链
    public static void coChainData() throws Exception {
        //请求报文, body部分数据会整体上链
        String reqData = "{\n" +
                "\t\"syshead\": {\n" +
                "\t\t\"consumerSysid\": \"123456\",\n" +
                "\t\t\"date\": \"20220512\",\n" +
                "\t\t\"time\": \"1526\",\n" +
                "\t\t\"tellerNo\": \"65414445451212\",\n" +
                "\t\t\"organNo\": \"501161000019\"\n" +
                "\t},\n" +
                "\t\"body\": {\n" +
                "\t\t\"userDid\": \"did:HSBC:0004:20220615e6861c88ed864c7ebb77441850dd562a\",\n" +
                "\t\t\"dataType\": \"INCOME_INFO\",\n" +
                "\t\t\"hasFile\": false,\n" +
                "\t\t\"content\": {\n" +
                "\t\t\t\"phoneNo\": \"18811117777\",\n" +
                "\t\t\t\"userName\": \"zhoulei\",\n" +
                "\t\t\t\"CountryOfOrigin\": \"中国\",\n" +
                "\t\t\t\"MoneyCome\": \"DUWEI\",\n" +
                "\t\t\t\"occupation\": \"创业者\",\n" +
                "\t\t\t\"initialCapital\": \"天使融资\",\n" +
                "\t\t\t\"CountryOfOriginNumber\": \"500000.00（元）\",\n" +
                "\t\t\t\"MoneyType\": \"现金\",\n" +
                "\t\t\t\"nowDataMoney\": \"无\",\n" +
                "\t\t\t\"idNo\": \"610322198511214839\",\n" +
                "\t\t\t\"email\": \"zhouleik@dcits.com\"\n" +
                "\t\t},\n" +
                "\t\t\"fileInfo\": {\n" +
                "\t\t\t\"fileList\": []\n" +
                "\t\t}\n" +
                "\t}\n" +
                "}";

        //请求流水号
        String seqNo = DidServiceSDK.getSeqNo(DidSystemConfig.getInstance().getSystemId());
        //当前接口对应的URL
        String serviceUrl = ServiceUrlConstant.SAVE_DATA_CHAIN_URL;
        //发送并返回响应报文

        String responsData = DidServiceSDK.sendToSaaS(reqData, seqNo, serviceUrl);
        System.out.println("响应报文 =====>" + responsData);
    }

    //2.3数据查看权限申请
    public static void permissionToView() throws Exception {
        //请求报文
        String reqData = "{\n" +
                "\t\"syshead\": {\n" +
                "\t\t\"date\": \"20220512\",\n" +
                "\t\t\"consumerSysid\": \"123456\",\n" +
                "\t\t\"tellerNo\": \"65414445451212\",\n" +
                "\t\t\"organNo\": \"501161000019\",\n" +
                "\t\t\"time\": \"1526\"\n" +
                "\t},\n" +
                "\t\"body\": {\n" +
                "\t\t\"dataType\": \"INCOME_INFO\",\n" +
                "\t\t\"partyId\": \"501161000020\",\n" +
                "\t\t\"userDid\": \"did:HSBC:0004:20220615e6861c88ed864c7ebb77441850dd562a\"\n" +
                "\t}\n" +
                "}";

        //请求流水号
        String seqNo = DidServiceSDK.getSeqNo(DidSystemConfig.getInstance().getSystemId());
        //当前接口对应的URL
        String serviceUrl = ServiceUrlConstant.APPLY_AUTHORITY_DATA_URL;
        //发送并返回响应报文
        String responsData = DidServiceSDK.sendToSaaS(reqData, seqNo, serviceUrl);
        System.out.println("响应报文 =====>" + responsData);
    }

    //2.4待授权信息查询
    public static void applicationEnquiry() throws Exception {
        //请求报文
        String reqData = "{\n" +
                "\t\"syshead\": {\n" +
                "\t\t\"date\": \"20220512\",\n" +
                "\t\t\"consumerSysid\": \"123456\",\n" +
                "\t\t\"tellerNo\": \"65414445451212\",\n" +
                "\t\t\"organNo\": \"501161000019\",\n" +
                "\t\t\"time\": \"1526\"\n" +
                "\t},\n" +
                "\t\"body\": {\n" +
                "\t\t\"userDid\": \"did:HSBC:0004:20220615e6861c88ed864c7ebb77441850dd562a\"\n" +
                "\t}\n" +
                "}";

        //请求流水号
        String seqNo = DidServiceSDK.getSeqNo(DidSystemConfig.getInstance().getSystemId());
        //当前接口对应的URL
        String serviceUrl = ServiceUrlConstant.INFORMATION_QUERY_URL;
        //发送并返回响应报文
        String responsData = DidServiceSDK.sendToSaaS(reqData, seqNo, serviceUrl);
        System.out.println("响应报文 =====>" + responsData);
    }

    //2.5用户授权
    public static void authorization() throws Exception {
        //请求报文
        String reqData = "{\n" +
                "\t\"syshead\": {\n" +
                "\t\t\"consumerSysid\": \"123456\",\n" +
                "\t\t\"date\": \"20220512\",\n" +
                "\t\t\"time\": \"1526\",\n" +
                "\t\t\"tellerNo\": \"65414445451212\",\n" +
                "\t\t\"organNo\": \"501161000019\"\n" +
                "\t},\n" +
                "\t\"body\": {\n" +
                "\t\t\"userDid\": \"did:HSBC:0004:20220615e6861c88ed864c7ebb77441850dd562a\",\n" +
                "\t\t\"checkKey\": {\n" +
                "\t\t\t\"did\": \"did:weid:3333:0xf82c3598391fcba1ff631fb669eef5407763d6b6\",\n" +
                "\t\t\t\"checkKeyList\": [{\n" +
                "\t\t\t\t\t\"type\": \"INCOME_INFO\",\n" +
                "\t\t\t\t\t\"checkKey\": \"eIdBKaRBsHv0rFDXR+OyKIAadEBmR/LLa82jLQgGCGBwkH2G0l02IY307ohrNpMV6k5CD8BE8o8qXoiFvVmM2/lYDfT+4lMfIIF5cJFEiyjJ+gvOpXN89FGo5M1nkmLqsPqToelQwSef7MCKyHVgh/uQv+9fivwA3QqmocN4IEU=\"\n" +
                "\t\t\t\t},\n" +
                "\t\t\t\t{\n" +
                "\t\t\t\t\t\"type\": \"SITE_INFO\",\n" +
                "\t\t\t\t\t\"checkKey\": \"CvTYRiEQXz50MjABo7uw6Ie9VI047UzrWd4N1+x43Hvhxn6nFWek6Ib3aY5FMx+GIxxZ43G1mvOxYvax3A7Z/TlXllwpxYsb78wDx3yfENuo0AGLyVaZGqHWylP6QBEPRKb5BlzLCjq/mk12ptKh2wbrznb+dhEblZzFMzHzC90=\"\n" +
                "\t\t\t\t}\n" +
                "\t\t\t]\n" +
                "\t\t},\n" +
                "\t\t\"seqNo\": \"1655257386091\"\n" +
                "\t}\n" +
                "}";

        //请求流水号
        String seqNo = DidServiceSDK.getSeqNo(DidSystemConfig.getInstance().getSystemId());
        //当前接口对应的URL
        String serviceUrl = ServiceUrlConstant.USER_AUTHORIZATION_URL;
        //发送并返回响应报文
        String responsData = DidServiceSDK.sendToSaaS(reqData, seqNo, serviceUrl);
        System.out.println("响应报文 =====>" + responsData);
    }


    //2.6权限申请结果查询
    public static void UserApplicationEnquiry() throws Exception {
        //请求报文
        String reqData = "{\n" +
                "\t\"syshead\": {\n" +
                "\t\t\"date\": \"20220512\",\n" +
                "\t\t\"consumerSysid\": \"123456\",\n" +
                "\t\t\"tellerNo\": \"65414445451212\",\n" +
                "\t\t\"organNo\": \"501161000019\",\n" +
                "\t\t\"time\": \"1526\"\n" +
                "\t},\n" +
                "\t\"body\": {\n" +
                "\t\t\"seqNo\": \"1654854921969\"\n" +
                "\t}\n" +
                "}";

        //请求流水号
        String seqNo = DidServiceSDK.getSeqNo(DidSystemConfig.getInstance().getSystemId());
        //当前接口对应的URL
        String serviceUrl = ServiceUrlConstant.AUTHORIZATION_QUERY_URL;
        //发送并接收响应报文
        String responsData = DidServiceSDK.sendToSaaS(reqData, seqNo, serviceUrl);
        System.out.println("响应报文 ==>" + responsData);

        //解析响应报文,判断查询到的授权结果
        //1-处理中，继续查询，
        //2-授权申请被拒绝,结束本次交易，
        //0-授权成功，调用工具方法解密，得到密钥组
        JSONObject respJson = JSONObject.parseObject(responsData);
        int status = Integer.parseInt(respJson.getJSONObject("body").getString("status"));
        Map<String, byte[]> keyMap = new HashMap<>();
        switch (status) {
            case 1:
                //一定间隔后再次查询
                break;
            case 2:
                //授权申请被拒绝,结束本次交易
                break;
            case 0:
                //授权成功，调用工具方法解密，得到密钥组
                //申请授权方的私钥作为入参，格式为私钥的BASE64串，需要自己维护
                String privateKeyStr = "MIICdwIBADANBgkqhkiG9w0BAQEFAASCAmEwggJdAgEAAoGBALeF/6x1rzphzwlu3tM1/sHZyiIjpoFqMr5vw3uNqs+c9AH0DhIqmhx37chirGgW1IBXE0WXaODY/oo08Y936R7kumLQXllUv5wunDiMCglQ7StHafSqIdiXDQdMQh96k7MmMNiaU9mCoW+B408Hg2HLw52a2sQdo6CpOhKAe9pBAgMBAAECgYAY4AXGp3Dn1egNHEUBldkBB3cZZ4GjGvTj0RxK++nCGEEOnrjlh3a6ExtcxNsfhLCq8KKBFUO27lKaAxEW5CbpuUnhUzQbLL7qAH760EkS9AkJ/GK85voS3PZWQ3VzLwLXHQfYdSwZmItvBS5NxZVae50FL7yMzEXUurDcPb4MAQJBAN5Dd4BfBXpnZvx1yyS2DmFLmMHo69CFM41zjJxFMW3mCeN2MhgElnYW+N9TGzzRicNUiQmwulUt80wb7wxGSiECQQDTYTNi+grx4x+DGnzBrdwu1OYG6OPphU5Kfo5C8d+nz5Phb+EvJoS1iQGVPVHpNeQb7hAiy3BE0yMwogRBGswhAkArOGNcix29l63nGeDO2rghI1opGuoAOmaz8uw81xetjzYNDUbgdMPtYroycy6wvO5VFXMwdzVEqxLMkgICGQkBAkEAoarZ7n1nGZGobFE50bfziy3xsJ82kUgPlRIuJC1x7Zrpc6ZqB/Hh1iYvO8FmgINjL6loVfRarYj+hRelQVYJgQJBAM2n6boJZi36gLOjwekm19dI34e6ca41v1BSiQCn9oJ/kFHQ9WqNeCPdbnVsny4Z1K3zW3/VfDAl1P0IhejFcJg=";
                String checkKeyList = respJson.getJSONObject("body").getString("checkKeyList");
                keyMap = DidSecurityTools.getKeyMap(checkKeyList, privateKeyStr);
                break;

        }
        System.out.println("获取到的密钥组 ==>" + keyMap.toString());
        //将keyMap保存为全局变量，查询链上加密数据，解密代码中使用
        checkMap = keyMap;


    }

    //2.7查询链上加密数据
    public static void getChainList() throws Exception {
        //请求报文
        String reqData = "{\n" +
                "\t\"syshead\": {\n" +
                "\t\t\"date\": \"20220512\",\n" +
                "\t\t\"consumerSysid\": \"123456\",\n" +
                "\t\t\"tellerNo\": \"65414445451212\",\n" +
                "\t\t\"organNo\": \"501161000019\",\n" +
                "\t\t\"time\": \"1526\"\n" +
                "\t},\n" +
                "\t\"body\": {\n" +
                "\t\t\"seqNo\": \"1654854921969\"\n" +
                "\t}\n" +
                "}";


        //请求流水号
        String seqNo = DidServiceSDK.getSeqNo(DidSystemConfig.getInstance().getSystemId());
        //当前接口对应的URL
        String serviceUrl = ServiceUrlConstant.QUERY_DATA_URL;
        //发送并返回响应报文
        String responsData = DidServiceSDK.sendToSaaS(reqData, seqNo, serviceUrl);

        //1、解析链上获取的加密数据
        JSONObject bodyJson = JSONObject.parseObject(responsData).getJSONObject("body");

        //获取所有类型的数据列表
        JSONArray dataListArray = bodyJson.getJSONArray("dataList");
//        //转成对应实体类
//        List<DataInfo> dataList = JSONArray.parseArray(bodyJson.getString("dataList"), DataInfo.class);

        //循环处理每个类型数据
        for (int j = 0; j < dataListArray.size(); j++) {
            JSONObject dataInfoJson = dataListArray.getJSONObject(j);
            String data = dataInfoJson.getString("data");
            String type = dataInfoJson.getString("type");

            //2 从密钥组获取对应type类型的密钥
            byte[] secretKey = checkMap.get(type);

            //3 解密数据
            String afterStr = DidSecurityTools.getPKCS7Cont(secretKey, data, type);

            //4 验签  提供两种方式 1 本地验签 2 调用API远程验签
            //4.1 本地验签
            // publicKeyBase64 为使用方自己维护的公钥  不传时 使用数据中携带公钥验证数据
            boolean verifyResult = DidSecurityTools.verifyDataLocal(afterStr, null);
            if (!verifyResult) {
                return;
            }
            //4.2 远程验签
            //调用本DEMO中的checkData()示例

            //5 获取用户数据
            JSONObject userDataJson = JSONObject.parseObject(afterStr).getJSONObject("credentialSubject");
            System.out.println("解密数据类型为===>" + type + "解密后用户数据 ====>" + userDataJson.toJSONString());

            //将用户信息转成对应实体类

            //6 如果有文件则下载文件
            boolean hasFile = userDataJson.getBooleanValue("hasFile");

            if (hasFile) {
                //6.1获取文件信息列表
                JSONArray fileList = userDataJson.getJSONObject("fileInfo").getJSONArray("fileList");

                for (int i = 0; i < fileList.size(); i++) {
                    //6.2 获取当前文件信息
                    JSONObject fileInfoJson = (JSONObject) fileList.get(i);
                    String fileId = fileInfoJson.getString("fileId"); //文件ID
                    String signature = fileInfoJson.getString("signature");//文件签名
                    String did = fileInfoJson.getString("did");//签名机构的did
                    String aesRandomKey = fileInfoJson.getString("aesRandomKey");//文件密钥
                    //6.3  从文件服务器下载文件 提供两种方式 1 下载并解密  2 仅下载
                    String downFileSeqNo = DidServiceSDK.getSeqNo(DidSystemConfig.getInstance().getSystemId());
                    String localPath = "C:\\Users\\86183\\Desktop\\testFile"; //文件保存到的本地路径
                    //6.3.1下载并解密
                    boolean isSuccess = DidServiceSDK.downloadFileAndDecrypt(fileId, localPath, aesRandomKey, downFileSeqNo);
                    //6.3.2 仅下载(下载后需要用密钥aesRandomKey调用DIDSecurityUtil.decryptByAES(fileData, aesRandomKey)解密)
                    // didFileSDK.downloadFile(fileId, localPath, downFileSeqNo);
                    if (isSuccess) {
                        System.out.println("文件下载成功 ==>" + fileId);
                    }
                }
            }
        }
    }

    //2.8通过did 获取公钥
    public static void getPublicKey() throws Exception {
        //请求报文,通过用户did获取公钥
        String reqData = "{\n" +
                "\t\"syshead\": {\n" +
                "\t\t\"date\": \"20220512\",\n" +
                "\t\t\"consumerSysid\": \"123456\",\n" +
                "\t\t\"tellerNo\": \"65414445451212\",\n" +
                "\t\t\"organNo\": \"501161000019\",\n" +
                "\t\t\"time\": \"1526\"\n" +
                "\t},\n" +
                "\t\"body\": {\n" +
                "\t\t\"did\": \"did:HSBC:0004:20220615e6861c88ed864c7ebb77441850dd562a\"\n" +
                "\t}\n" +
                "}";

        //请求流水号
        String seqNo = DidServiceSDK.getSeqNo(DidSystemConfig.getInstance().getSystemId());
        //当前接口对应的URL
        String serviceUrl = ServiceUrlConstant.QUERY_PUBLICKEY_URL;
        //发送并返回响应报文
        String responsData = DidServiceSDK.sendToSaaS(reqData, seqNo, serviceUrl);
        System.out.println("响应报文 =====>" + responsData);
    }

    //2.9获取用户基本信息
    public static void userFind() throws Exception {
        //请求报文
        String reqData = "{\n" +
                "\t\"syshead\": {\n" +
                "\t\t\"date\": \"20220512\",\n" +
                "\t\t\"consumrSysid\": \"123456\",\n" +
                "\t\t\"tellerNo\": \"65414445451212\",\n" +
                "\t\t\"organNo\": \"501161000019\",\n" +
                "\t\t\"time\": \"1526\"\n" +
                "\t},\n" +
                "\t\"body\": {\n" +
                "\t\t\"userName\": \"xiaowei\"\n" +
                "\t}\n" +
                "}";

        //请求流水号
        String seqNo = DidServiceSDK.getSeqNo(DidSystemConfig.getInstance().getSystemId());
        //当前接口对应的URL
        String serviceUrl = ServiceUrlConstant.QUERY_USER_DATA_URL;
        //发送并返回响应报文
        String responsData = DidServiceSDK.sendToSaaS(reqData, seqNo, serviceUrl);
        System.out.println("响应报文 =====>" + responsData);
    }

    //2.10链上数据校验
    public static void checkData() throws Exception {
        //请求报文,数据为链上加密数据解密后数据，校验数据完整性
        String reqData = "{\n" +
                "\t\"syshead\": {\n" +
                "\t\t\"date\": \"20220512\",\n" +
                "\t\t\"consumrSysid\": \"123456\",\n" +
                "\t\t\"tellerNo\": \"65414445451212\",\n" +
                "\t\t\"organNo\": \"501161000019\",\n" +
                "\t\t\"time\": \"1526\"\n" +
                "\t},\n" +
                "\t\"body\": " +
                "{\n" +
                "\t\"issuanceDate\": \"2022-06-01T15:09:27Z\",\n" +
                "\t\"id\": \"did:weid:3333:0x8f86b648c236025efbbfec202742b22de8a12ee2\",\n" +
                "\t\"proof\": {\n" +
                "\t\t\"created\": \"2022-06-01T15:09:27 Z\",\n" +
                "\t\t\"jws\": \"GMv90HnAnt4cpNz3pMepOv7TtQhv5vUlUwXZg/rbcZQ54BOZXp7+4QolWl1waPbG63nNFe7TDimZYTzrssniKBymzA0pP6vJupghniZH0HxQkcG+GPMvnTbF5ezno07YdudKHm2Iv9VkqoW88UN8M5gw3lFfWPVf9ihd4TuoQXmQ1RkdZkDRY+BOV4GCxjJhASDPzjb4hquzV60e5Tmh7dyXjsuIA7EMrV+rnuP70ZVmPZFUizYkk9D4zB2w2kPGyVQpkct3NK2GFvjQ47jpVcVM67MsX9Wy/vt52cN2gnbl3Wmvny6eo/2QLfUqaPtJT75gCw2Nj7nZ+7G3ocHNCw==\",\n" +
                "\t\t\"proofPurpose\": \"assertionMethod\",\n" +
                "\t\t\"type\": \"RsaSignature2018\",\n" +
                "\t\t\"verificationMethod\": \"http://10.5.181.115:9898/biock-chain/checkData\",\n" +
                "\t\t\"publicKeyBase64\": \"MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAiBUbkWeIcnNRtUvdyDO/1241gHNMQSHetkuqTGuFJltpix7oZ+Q+8hi+azQ9URyxmHghMORvcwk0ck2qOYYD9t75cpt//rY9h9PX7fxJqYCBP5zVhfeSBbcex/n84c6uxgRsHxKaZ2A5LOM9vHaNotw6/V2bVRH/a/Fv4OC5SP3MizIVpejm3I81gZS9VHEUWsv4R0QjjsO7c+QIEUOpBDDtlokvc+dkVuahUZ2cHZGKtT+kT1VD3Yd9enY/xNwj7Ef3ItCb/YmCA/ngj4uONC+N0X7Femt7wxTjGwpKmSn+CPBR0t1lFExLKebihEuezpjGSpKTMO+V2HPX6BIu6wIDAQAB\"\n" +
                "\t},\n" +
                "\t\"type\": [\n" +
                "\t\t\"VerifiableCredential\",\n" +
                "\t\t\"AlumniCredential\"\n" +
                "\t],\n" +
                "\t\"@context\": [\n" +
                "\t\t\"https://www.w3.org/2018/credentials/v1\",\n" +
                "\t\t\"https://www.w3.org/2018/credentials/examples/v1\"\n" +
                "\t],\n" +
                "\t\"issuer\": \"https://hsbccn.com/issuer\",\n" +
                "\t\"credentialSubject\": {\n" +
                "\t\t\"userDid\": \"did:HSBC:0004:20220601f356314f32334f61b2358b63ba4d3c26\",\n" +
                "\t\t\"dataType\": \"BASE_INFO\",\n" +
                "\t\t\"hasFile\": true,\n" +
                "\t\t\"content\": {\n" +
                "\t\t\t\"email\": \"yangqijun@dcits.com\",\n" +
                "\t\t\t\"idNo\": \"610432199003081391\",\n" +
                "\t\t\t\"phoneNo\": \"18811116666\",\n" +
                "\t\t\t\"userName\": \"yangqijun\",\n" +
                "\t\t\t\"sex\": \"男\",\n" +
                "\t\t\t\"idType\": \"IT01\",\n" +
                "\t\t\t\"nationality\": \"中国\",\n" +
                "\t\t\t\"nation\": \"汉\",\n" +
                "\t\t\t\"formerName\": \"无\",\n" +
                "\t\t\t\"docType\": \"身份证\",\n" +
                "\t\t\t\"gender\": \"MAN\",\n" +
                "\t\t\t\"licence\": \"北京市市公安局\",\n" +
                "\t\t\t\"validity\": \"1900/01/01\"\n" +
                "\t\t},\n" +
                "\t\t\"fileInfo\": {\n" +
                "\t\t\t\"fileList\": [{\n" +
                "\t\t\t\t\t\"fileId\": \"1b3808b29d5242e9805ed06a5195c17d\",\n" +
                "\t\t\t\t\t\"signature\": \"EGIL5VrOIKZgS1Q8uexTgaGIsQNydOIIkzIcvOcU6R7g2gWOMXG3JDRfIo2wQ8HQHR7ba5fBszTDXpQ8ZnV5F7tlUjaNWTigrbsH3C/FrpsiPdohIr95L87vT5+JGgh4Uln6V4HUpvnJ5gXhzZP4Y1uYNwX30iIdbFbcAMc93iMgC3U1kJMwlJgCCRfGHTbXD6oWy5ubT33Ajv8COGmR/DdC6KhJNVTBFLZYR+Q9jmutlp8T/DzyQb0B0OeoRrAZYKsbtfQUg9T6tgalErC/zYpJt3R+yUFFcyCEOwlAsz+dTrUQWcUIh0LFP50kjm6xOsPgDCR7sdK6B2zlwett1g==\",\n" +
                "\t\t\t\t\t\"did\": \"did:weid:3333:0x8f86b648c236025efbbfec202742b22de8a12ee2\",\n" +
                "\t\t\t\t\t\"aesRandomKey\": \"F4C6NcEYtYYy1f9mI8sJJg==\"\n" +
                "\t\t\t\t},\n" +
                "\t\t\t\t{\n" +
                "\t\t\t\t\t\"fileId\": \"184f41430b554627a614397971656a15\",\n" +
                "\t\t\t\t\t\"signature\": \"PWCsHxFTvN0CFy7QEVA0XCR1VosoWl6XYRchUryrfslUXzmF0+6uizM9bA96DiK8e49NxglwEYWNFZPd8qDkxp4LLkCCPM06Nt9HuCiSabCnzTZeCyMP9QcPE9/rkEyJ9raUQLqw1WOXsf/mAkchVe2kjSQS/tKhFfBjqmtE7rHHFT+NltFc4USsn1yQ95DoifiReGRuMfrO524GAyX31Vm7akOr14USDktJZu+Q2p3LkXpTzjNUfgKHMt2sLiuOA9gtq0tQX3JDx4yE584uN4LAnoXNI2A+hkpI2EaZhcchNfjdZxJFepmGAViBFTvVvwMXjW6Dwl9HwjV7/oS2WA==\",\n" +
                "\t\t\t\t\t\"did\": \"did:weid:3333:0x8f86b648c236025efbbfec202742b22de8a12ee2\",\n" +
                "\t\t\t\t\t\"aesRandomKey\": \"BTkYN5rmXAGAeGVAJ6nn4w==\"\n" +
                "\t\t\t\t}\n" +
                "\t\t\t]\n" +
                "\t\t}\n" +
                "\t}\n" +
                "}\n" +
                "}";

        //请求流水号
        String seqNo = DidServiceSDK.getSeqNo(DidSystemConfig.getInstance().getSystemId());
        //当前接口对应的URL
        String serviceUrl = ServiceUrlConstant.CHECK_DATA_URL;
        //发送并返回响应报文
        String responsData = DidServiceSDK.sendToSaaS(reqData, seqNo, serviceUrl);
        System.out.println("响应报文 =====>" + responsData);
    }

}
